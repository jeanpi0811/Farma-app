import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import { router } from "expo-router";
import { colors } from "@/constants/colors";

export default function Onboarding() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Farma Bolso</Text>
      <Text style={styles.subtitle}>Sua saúde na palma da mão</Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Medicamentos organizados</Text>
        <Text style={styles.text}>Consulte informações simples, salve seus medicamentos e acompanhe tratamentos.</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Exames laboratoriais</Text>
        <Text style={styles.text}>Consulte valores de referência e entenda melhor seus resultados.</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>IA Farma</Text>
        <Text style={styles.text}>Receba orientações educativas sobre medicamentos, exames e cuidados gerais.</Text>
      </View>

      <Text style={styles.warning}>
        A IA Farma oferece informações educativas e não substitui atendimento médico, farmacêutico ou serviço de emergência.
      </Text>

      <TouchableOpacity style={styles.button} onPress={() => router.replace("/auth/login")}>
        <Text style={styles.buttonText}>Começar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 24, justifyContent: "center", backgroundColor: colors.background },
  title: { fontSize: 38, fontWeight: "900", color: colors.primary, textAlign: "center" },
  subtitle: { fontSize: 17, color: colors.textMuted, textAlign: "center", marginBottom: 28 },
  card: { backgroundColor: colors.surface, padding: 18, borderRadius: 18, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  cardTitle: { fontSize: 18, fontWeight: "800", color: colors.text },
  text: { marginTop: 6, color: colors.textMuted, lineHeight: 21 },
  warning: { fontSize: 13, color: colors.danger, textAlign: "center", marginVertical: 18 },
  button: { backgroundColor: colors.primary, padding: 16, borderRadius: 16 },
  buttonText: { color: "#fff", textAlign: "center", fontWeight: "800", fontSize: 16 }
});
