import { View, Text, TextInput, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { colors } from "@/constants/colors";

export default function Register() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Crie sua conta</Text>
      <Text style={styles.subtitle}>Organize seus medicamentos, acompanhe seus exames e cuide melhor da sua saúde.</Text>

      <TextInput placeholder="Nome" style={styles.input} />
      <TextInput placeholder="E-mail" style={styles.input} autoCapitalize="none" />
      <TextInput placeholder="Senha" style={styles.input} secureTextEntry />

      <TouchableOpacity style={styles.button} onPress={() => router.replace("/(tabs)/home")}>
        <Text style={styles.buttonText}>Cadastrar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: "center", backgroundColor: colors.background },
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  subtitle: { color: colors.textMuted, marginTop: 8, marginBottom: 24, lineHeight: 22 },
  input: { backgroundColor: colors.surface, padding: 15, borderRadius: 14, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  button: { backgroundColor: colors.primary, padding: 16, borderRadius: 16, marginTop: 8 },
  buttonText: { color: "#fff", textAlign: "center", fontWeight: "800" }
});
