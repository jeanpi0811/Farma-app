import { Text, StyleSheet } from "react-native";
import { Screen } from "@/components/Screen";
import { Card } from "@/components/Card";
import { colors } from "@/constants/colors";

export default function Mais() {
  return (
    <Screen>
      <Text style={styles.title}>Mais</Text>
      <Text style={styles.subtitle}>Configurações, Minha Saúde, Favoritos, Premium e suporte.</Text>

      <Card>
        <Text style={styles.item}>Minha Saúde</Text>
        <Text style={styles.text}>Mantenha suas informações de saúde organizadas e sempre à mão.</Text>
      </Card>

      <Card>
        <Text style={styles.item}>Verificar interações</Text>
        <Text style={styles.text}>Selecione dois ou mais medicamentos para consultar possíveis riscos de interação.</Text>
      </Card>

      <Card>
        <Text style={styles.item}>Relatórios em PDF</Text>
        <Text style={styles.text}>Exporte um resumo organizado de saúde para levar ao médico ou farmacêutico.</Text>
      </Card>

      <Card premium>
        <Text style={styles.premium}>Premium</Text>
        <Text style={styles.text}>Mensal R$ 19,90 • Anual R$ 149,90 • 7 dias grátis.</Text>
      </Card>

      <Card>
        <Text style={styles.item}>Farmacêutico Online</Text>
        <Text style={styles.text}>Em breve: atendimento online com farmacêutico.</Text>
      </Card>

      <Card>
        <Text style={styles.item}>Suporte</Text>
        <Text style={styles.text}>jeanpi0811@hotmail.com</Text>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  subtitle: { color: colors.textMuted, marginBottom: 18 },
  item: { fontSize: 18, fontWeight: "900", color: colors.text },
  premium: { fontSize: 18, fontWeight: "900", color: colors.gold },
  text: { color: colors.textMuted, marginTop: 6, lineHeight: 21 }
});
