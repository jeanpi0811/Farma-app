import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "@/constants/colors";

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarStyle: {
          height: 64,
          paddingBottom: 8,
          paddingTop: 8,
          backgroundColor: colors.surface,
          borderTopColor: colors.border
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: "700" }
      }}
    >
      <Tabs.Screen name="home" options={{ title: "Home", tabBarIcon: ({ color }) => <Ionicons name="home" size={22} color={color} /> }} />
      <Tabs.Screen name="medicamentos" options={{ title: "Medicamentos", tabBarIcon: ({ color }) => <Ionicons name="medical" size={22} color={color} /> }} />
      <Tabs.Screen name="exames" options={{ title: "Exames", tabBarIcon: ({ color }) => <Ionicons name="flask" size={22} color={color} /> }} />
      <Tabs.Screen name="ia" options={{ title: "IA Farma", tabBarIcon: ({ color }) => <Ionicons name="sparkles" size={22} color={color} /> }} />
      <Tabs.Screen name="mais" options={{ title: "Mais", tabBarIcon: ({ color }) => <Ionicons name="menu" size={22} color={color} /> }} />
    </Tabs>
  );
}
