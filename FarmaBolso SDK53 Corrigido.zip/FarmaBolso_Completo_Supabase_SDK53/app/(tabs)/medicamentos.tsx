import { Text, StyleSheet } from "react-native";
import { Screen } from "@/components/Screen";
import { Card } from "@/components/Card";
import { medicamentos } from "@/data/medicamentos";
import { colors } from "@/constants/colors";

export default function Medicamentos() {
  return (
    <Screen>
      <Text style={styles.title}>Medicamentos</Text>
      <Text style={styles.subtitle}>Consulte informações simples e organize seus tratamentos.</Text>

      {medicamentos.map((m) => (
        <Card key={m.nome}>
          <Text style={styles.name}>{m.nome}</Text>
          <Text style={styles.active}>{m.principioAtivo} • {m.categoria}</Text>
          <Text style={styles.text}>{m.resumo}</Text>
          <Text style={styles.care}>Cuidados: {m.cuidados}</Text>
        </Card>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  subtitle: { color: colors.textMuted, marginBottom: 18 },
  name: { fontSize: 19, fontWeight: "900", color: colors.primary },
  active: { color: colors.textMuted, marginTop: 4, fontWeight: "700" },
  text: { color: colors.text, marginTop: 8, lineHeight: 21 },
  care: { color: colors.textMuted, marginTop: 8, fontSize: 13, lineHeight: 19 }
});
