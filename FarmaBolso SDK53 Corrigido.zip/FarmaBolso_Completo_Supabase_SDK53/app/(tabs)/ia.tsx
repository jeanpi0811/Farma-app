import { useState } from "react";
import { Text, StyleSheet, TextInput, TouchableOpacity, View } from "react-native";
import { Screen } from "@/components/Screen";
import { Card } from "@/components/Card";
import { colors } from "@/constants/colors";

export default function IAFarma() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("Faça uma pergunta sobre medicamentos, exames ou cuidados gerais.");

  function responder() {
    if (!question.trim()) return;
    setAnswer("Resposta educativa da IA Farma: para uma orientação segura, informe idade, medicamentos em uso, alergias e contexto. Este app não substitui atendimento profissional.");
  }

  return (
    <Screen>
      <Text style={styles.title}>IA Farma</Text>
      <Text style={styles.subtitle}>FarmaBot: orientação educativa em linguagem simples.</Text>

      <Card>
        <Text style={styles.warning}>
          A IA Farma oferece informações educativas e não substitui atendimento médico, farmacêutico ou serviço de emergência. Em caso de sintomas graves ou reação inesperada, procure atendimento de saúde imediatamente.
        </Text>
      </Card>

      <TextInput
        style={styles.input}
        placeholder="Digite sua dúvida..."
        value={question}
        onChangeText={setQuestion}
        multiline
      />
      <TouchableOpacity style={styles.button} onPress={responder}>
        <Text style={styles.buttonText}>Perguntar</Text>
      </TouchableOpacity>

      <View style={styles.answerBox}>
        <Text style={styles.answer}>{answer}</Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  subtitle: { color: colors.textMuted, marginBottom: 18 },
  warning: { color: colors.danger, lineHeight: 20 },
  input: { minHeight: 120, backgroundColor: colors.surface, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: colors.border, textAlignVertical: "top" },
  button: { marginTop: 12, backgroundColor: colors.primary, padding: 15, borderRadius: 16 },
  buttonText: { color: "#fff", fontWeight: "900", textAlign: "center" },
  answerBox: { marginTop: 16, padding: 16, borderRadius: 16, backgroundColor: "#ECFDF5" },
  answer: { color: colors.text, lineHeight: 22 }
});
