import { Text, View, StyleSheet } from "react-native";
import { Screen } from "@/components/Screen";
import { Card } from "@/components/Card";
import { colors } from "@/constants/colors";

export default function Home() {
  return (
    <Screen>
      <Text style={styles.title}>Olá, tudo bem?</Text>
      <Text style={styles.subtitle}>Veja seu resumo de saúde de hoje.</Text>

      <Card>
        <Text style={styles.cardTitle}>Medicamentos de hoje</Text>
        <Text style={styles.text}>Nenhum lembrete pendente cadastrado.</Text>
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Tire dúvidas com a IA Farma</Text>
        <Text style={styles.text}>Receba orientações educativas sobre medicamentos, exames e cuidados gerais.</Text>
      </Card>

      <Card premium>
        <Text style={styles.premium}>Farma Bolso Premium</Text>
        <Text style={styles.text}>Desbloqueie IA ilimitada, interações medicamentosas, relatórios em PDF e recursos avançados.</Text>
      </Card>

      <View style={styles.warningBox}>
        <Text style={styles.warning}>A IA Farma oferece informações educativas e não substitui atendimento médico, farmacêutico ou serviço de emergência.</Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  subtitle: { color: colors.textMuted, marginBottom: 18 },
  cardTitle: { fontSize: 18, fontWeight: "800", color: colors.text },
  premium: { fontSize: 18, fontWeight: "900", color: colors.gold },
  text: { marginTop: 6, color: colors.textMuted, lineHeight: 21 },
  warningBox: { backgroundColor: "#FEF2F2", padding: 14, borderRadius: 14, borderWidth: 1, borderColor: "#FECACA" },
  warning: { color: colors.danger, fontSize: 13, lineHeight: 19 }
});
