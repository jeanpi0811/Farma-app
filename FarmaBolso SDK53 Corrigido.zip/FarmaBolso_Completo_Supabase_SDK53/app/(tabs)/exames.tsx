import { Text, StyleSheet } from "react-native";
import { Screen } from "@/components/Screen";
import { Card } from "@/components/Card";
import { exames } from "@/data/exames";
import { colors } from "@/constants/colors";

export default function Exames() {
  return (
    <Screen>
      <Text style={styles.title}>Exames laboratoriais</Text>
      <Text style={styles.subtitle}>Consulte valores de referência e entenda melhor seus resultados.</Text>

      {exames.map((e) => (
        <Card key={e.nome}>
          <Text style={styles.name}>{e.nome}</Text>
          <Text style={styles.category}>{e.categoria}</Text>
          <Text style={styles.ref}>Referência: {e.referencia}</Text>
          <Text style={styles.text}>Alto: {e.alto}</Text>
          <Text style={styles.text}>Baixo: {e.baixo}</Text>
        </Card>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  subtitle: { color: colors.textMuted, marginBottom: 18 },
  name: { fontSize: 19, fontWeight: "900", color: colors.primary },
  category: { color: colors.textMuted, marginTop: 4, fontWeight: "700" },
  ref: { color: colors.text, marginTop: 8, fontWeight: "700" },
  text: { color: colors.textMuted, marginTop: 6, lineHeight: 20 }
});
