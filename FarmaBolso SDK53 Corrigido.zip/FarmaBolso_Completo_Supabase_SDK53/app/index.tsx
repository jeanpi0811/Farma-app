import { useEffect } from "react";
import { View, Text, Image, StyleSheet } from "react-native";
import { router } from "expo-router";
import { colors } from "@/constants/colors";

export default function SplashScreen() {
  useEffect(() => {
    const timer = setTimeout(() => router.replace("/onboarding"), 1200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      <Image source={require("@/assets/images/splash-icon.png")} style={styles.logo} resizeMode="contain" />
      <Text style={styles.name}>Farma Bolso</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.navy, alignItems: "center", justifyContent: "center" },
  logo: { width: 160, height: 160, marginBottom: 16 },
  name: { color: "#fff", fontSize: 30, fontWeight: "800" }
});
