create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  email text,
  role text default 'user',
  plan_type text default 'free',
  created_at timestamp with time zone default now()
);

create table if not exists medications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  name text not null,
  active_ingredient text,
  dosage text,
  frequency text,
  notes text,
  created_at timestamp with time zone default now()
);

create table if not exists exam_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  exam_name text not null,
  value text,
  unit text,
  measured_at date,
  notes text,
  created_at timestamp with time zone default now()
);

create table if not exists ai_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  question text not null,
  answer text not null,
  created_at timestamp with time zone default now()
);
