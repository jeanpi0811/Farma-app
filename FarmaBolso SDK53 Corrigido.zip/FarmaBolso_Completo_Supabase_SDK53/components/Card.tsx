import { ReactNode } from "react";
import { View, StyleSheet } from "react-native";
import { colors } from "@/constants/colors";

export function Card({ children, premium = false }: { children: ReactNode; premium?: boolean }) {
  return <View style={[styles.card, premium && styles.premium]}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 12
  },
  premium: {
    borderColor: colors.gold,
    backgroundColor: "#FFFDF5"
  }
});
