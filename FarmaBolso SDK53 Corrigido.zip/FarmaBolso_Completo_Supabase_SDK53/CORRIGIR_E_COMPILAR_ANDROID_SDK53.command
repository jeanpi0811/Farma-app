#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "=============================================="
echo " Farma Bolso - Correção Android Expo SDK 53"
echo "=============================================="

echo ""
echo "1/7 - Removendo caches e builds antigos..."
rm -rf node_modules package-lock.json .expo android/.gradle android/build android/app/build 2>/dev/null || true

echo ""
echo "2/7 - Instalando dependências com compatibilidade..."
npm install --legacy-peer-deps

echo ""
echo "3/7 - Rodando expo doctor..."
npx expo-doctor || true

echo ""
echo "4/7 - Limpando cache do Expo..."
npx expo start --clear
