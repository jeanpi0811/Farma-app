export const colors = {
  primary: "#0F766E",
  teal: "#1E3A5F",
  navy: "#0F172A",
  background: "#F5F7FA",
  surface: "#FFFFFF",
  text: "#111827",
  textMuted: "#6B7280",
  border: "#E5E7EB",
  gold: "#C9A227",
  danger: "#B91C1C",
  success: "#15803D"
};
