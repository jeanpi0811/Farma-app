import { createContext, useContext, ReactNode } from "react";
import { colors } from "@/constants/colors";

const ThemeContext = createContext({ colors });

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <ThemeContext.Provider value={{ colors }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
