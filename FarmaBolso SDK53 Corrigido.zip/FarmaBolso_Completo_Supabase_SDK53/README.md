# Farma Bolso - Expo SDK 53 + Supabase

Projeto recriado para o app **Farma Bolso**.

## Dados do app

- Nome: Farma Bolso
- Desenvolvedor: Jean Pierre Andres
- Slogan: Sua saúde na palma da mão
- Pacote Android: `com.farmabolso.app`
- Bundle iOS: `com.farmabolso.app`
- Tecnologia: Expo SDK 53, React Native, TypeScript e Supabase

## Rodar

```bash
npm install --legacy-peer-deps
npx expo start --clear
```

## Android

```bash
npx expo prebuild --platform android --clean
npx expo run:android
```

## EAS Build Android

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build -p android --profile preview
```

## Supabase

Copie `.env.example` para `.env` e preencha:

```bash
EXPO_PUBLIC_SUPABASE_URL=
EXPO_PUBLIC_SUPABASE_ANON_KEY=
```

## Observação de segurança

A IA Farma é educativa e não substitui médico, farmacêutico ou serviço de emergência.
