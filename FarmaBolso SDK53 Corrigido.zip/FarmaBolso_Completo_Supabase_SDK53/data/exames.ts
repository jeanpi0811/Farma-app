export const exames = [
  { nome: "Hemoglobina", categoria: "Hemograma", referencia: "Homens: 13,5-17,5 g/dL; Mulheres: 12-16 g/dL", alto: "Pode sugerir desidratação ou policitemia.", baixo: "Pode sugerir anemia." },
  { nome: "Leucócitos", categoria: "Hemograma", referencia: "4.000-11.000/mm³", alto: "Pode ocorrer em infecções/inflamações.", baixo: "Pode ocorrer por viroses, medicamentos ou alterações imunológicas." },
  { nome: "Glicose em jejum", categoria: "Diabetes", referencia: "70-99 mg/dL", alto: "Pode sugerir pré-diabetes ou diabetes.", baixo: "Pode indicar hipoglicemia." },
  { nome: "Colesterol total", categoria: "Lipidograma", referencia: "Desejável abaixo de 190 mg/dL", alto: "Pode aumentar risco cardiovascular.", baixo: "Geralmente avaliar contexto clínico." },
  { nome: "Creatinina", categoria: "Função renal", referencia: "Varia por sexo, idade e massa muscular", alto: "Pode indicar alteração da função renal.", baixo: "Pode estar ligado à baixa massa muscular." },
  { nome: "TGO/AST", categoria: "Função hepática", referencia: "Geralmente até 40 U/L", alto: "Pode indicar lesão hepática, muscular ou outras causas.", baixo: "Normalmente sem relevância isolada." },
  { nome: "TSH", categoria: "Tireoide", referencia: "Aproximadamente 0,4-4,0 mUI/L", alto: "Pode sugerir hipotireoidismo.", baixo: "Pode sugerir hipertireoidismo." },
  { nome: "Vitamina D", categoria: "Vitaminas", referencia: "Consultar referência do laboratório", alto: "Pode ocorrer por suplementação excessiva.", baixo: "Pode indicar deficiência." }
];
