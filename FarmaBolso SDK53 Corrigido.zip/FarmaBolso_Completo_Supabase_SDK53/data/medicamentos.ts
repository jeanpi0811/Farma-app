export const medicamentos = [
  {
    nome: "Dipirona",
    principioAtivo: "Metamizol sódico",
    categoria: "Dor e febre",
    resumo: "Usada para alívio de dor e febre.",
    cuidados: "Evitar em alergia à dipirona. Procurar orientação em gravidez, amamentação ou reações inesperadas."
  },
  {
    nome: "Paracetamol",
    principioAtivo: "Paracetamol",
    categoria: "Dor e febre",
    resumo: "Usado para febre e dores leves a moderadas.",
    cuidados: "Cuidado com doses altas e uso junto com álcool por risco ao fígado."
  },
  {
    nome: "Ibuprofeno",
    principioAtivo: "Ibuprofeno",
    categoria: "Anti-inflamatório",
    resumo: "Anti-inflamatório usado para dor, febre e inflamação.",
    cuidados: "Cautela em gastrite, problemas renais, anticoagulantes e pressão alta."
  },
  {
    nome: "Amoxicilina",
    principioAtivo: "Amoxicilina",
    categoria: "Antibiótico",
    resumo: "Antibiótico usado em infecções bacterianas conforme prescrição.",
    cuidados: "Não usar sem prescrição. Completar o tratamento indicado."
  },
  {
    nome: "Loratadina",
    principioAtivo: "Loratadina",
    categoria: "Alergia",
    resumo: "Antialérgico para rinite, coceira e urticária.",
    cuidados: "Pode exigir cuidado em doença hepática."
  },
  {
    nome: "Omeprazol",
    principioAtivo: "Omeprazol",
    categoria: "Estômago",
    resumo: "Reduz acidez do estômago.",
    cuidados: "Uso prolongado deve ser acompanhado por profissional."
  },
  {
    nome: "Losartana",
    principioAtivo: "Losartana potássica",
    categoria: "Pressão",
    resumo: "Usada no controle da pressão arterial.",
    cuidados: "Monitorar pressão, função renal e potássio conforme orientação."
  },
  {
    nome: "Metformina",
    principioAtivo: "Cloridrato de metformina",
    categoria: "Diabetes",
    resumo: "Auxilia no controle da glicose no diabetes tipo 2.",
    cuidados: "Cautela em doença renal. Pode causar desconforto gastrointestinal."
  },
  {
    nome: "Sinvastatina",
    principioAtivo: "Sinvastatina",
    categoria: "Colesterol",
    resumo: "Usada para controle de colesterol.",
    cuidados: "Atenção a dor muscular intensa e interações medicamentosas."
  },
  {
    nome: "AAS",
    principioAtivo: "Ácido acetilsalicílico",
    categoria: "Cardiovascular",
    resumo: "Usado como antiagregante plaquetário em algumas situações.",
    cuidados: "Pode aumentar risco de sangramento. Usar conforme orientação."
  }
];
